import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class FinalView extends JFrame {

	private JPanel contentPane;

/*	*//**
	 * Launch the application.
	 *//*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ParchasePage frame = new ParchasePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	*//**
	 * Create the frame.
	 */
	private String phone;
	
	public FinalView(String phone) {
		this.phone = phone;
		
		

		setTitle("Final View");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 780);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				Home obj = new Home();
				obj.setVisible(true);
			}
		});
		btnLogout.setBounds(785, 31, 130, 41);
		contentPane.add(btnLogout);
		
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel.setBounds(51, 76, 145, 57);
		contentPane.add(lblNewLabel);
		
		name_lb = new JLabel("Sadhan Sarker");
		name_lb.setFont(new Font("Tahoma", Font.BOLD, 23));
		name_lb.setBounds(243, 84, 259, 49);
		contentPane.add(name_lb);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblPhone.setBounds(51, 176, 145, 57);
		contentPane.add(lblPhone);
		
		phone_lb = new JLabel("Sadhan Sarker");
		phone_lb.setFont(new Font("Tahoma", Font.BOLD, 23));
		phone_lb.setBounds(243, 184, 259, 49);
		contentPane.add(phone_lb);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblEmail.setBounds(51, 266, 145, 57);
		contentPane.add(lblEmail);
		
		email_lb = new JLabel("s@example.com");
		email_lb.setFont(new Font("Tahoma", Font.BOLD, 23));
		email_lb.setBounds(243, 274, 259, 49);
		contentPane.add(email_lb);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblPrice.setBounds(51, 361, 145, 57);
		contentPane.add(lblPrice);
		
		price_lb = new JLabel("s@example.com");
		price_lb.setFont(new Font("Tahoma", Font.BOLD, 23));
		price_lb.setBounds(243, 369, 259, 49);
		contentPane.add(price_lb);
		
		time_lb = new JLabel("334");
		time_lb.setFont(new Font("Tahoma", Font.BOLD, 23));
		time_lb.setBounds(243, 451, 259, 49);
		contentPane.add(time_lb);
		
		JLabel dfd = new JLabel("Time:");
		dfd.setFont(new Font("Tahoma", Font.BOLD, 23));
		dfd.setBounds(51, 443, 145, 57);
		contentPane.add(dfd);
		
		JLabel lblMovieName = new JLabel("Movie Name");
		lblMovieName.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblMovieName.setBounds(51, 543, 145, 57);
		contentPane.add(lblMovieName);
		
		movie_name_lb = new JLabel("334");
		movie_name_lb.setFont(new Font("Tahoma", Font.BOLD, 23));
		movie_name_lb.setBounds(243, 551, 259, 49);
		contentPane.add(movie_name_lb);
		
		getAllValue();
		
	}
	
	private Connection conn;
	private JLabel name_lb;
	private JLabel phone_lb;
	private JLabel email_lb;
	private JLabel price_lb;
	private JLabel time_lb;
	private JLabel movie_name_lb;

	private void getAllValue() {
		
		System.out.println(phone);
		
		conn = 	DB_Mysql_Connect.connectDB();
		System.out.print("Database is connected !");
		
		try{
			String query = "select * from user_info WHERE phone='"+ phone +"'";
			
			//System.out.println(query);
			
			Statement stt = conn.createStatement();

			ResultSet rs = stt.executeQuery(query);
			//System.out.println("Id   First Name    Last Name");
			while (rs.next()) {
			
				name_lb.setText(rs.getString("name"));
				phone_lb.setText(rs.getString("phone"));
				email_lb.setText(rs.getString("email"));
				price_lb.setText(rs.getString("price"));
				time_lb.setText(rs.getString("show_time"));
				movie_name_lb.setText(rs.getString("movie_name"));
			
			}
			conn.close();
			
		}catch(Exception ee){
			System.err.println(ee);
		}
		
	}
}
