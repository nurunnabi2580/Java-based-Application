import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Home extends JFrame {
	
	private JPanel contentPane;
	private JLabel movie_label1;
	private JLabel movie_label2;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Home() {
		setTitle("Home Page");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 780);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton homeButton = new JButton("Home");
		homeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		homeButton.setBounds(106, 36, 141, 41);
		contentPane.add(homeButton);
		
		JButton parchaseButton = new JButton("Parchase");
		parchaseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				LoginPage obj = new LoginPage();
				obj.setVisible(true);
			}
		});
		parchaseButton.setBounds(269, 36, 130, 41);
		contentPane.add(parchaseButton);
		
		JButton memberButton = new JButton("Member");
		memberButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				MemberPage obj = new MemberPage();
				obj.setVisible(true);
			}
		});
		memberButton.setBounds(422, 36, 125, 41);
		contentPane.add(memberButton);
		
		JButton contactButton = new JButton("Contact");
		contactButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ContactPage obj = new ContactPage();
				obj.setVisible(true);
			}
		});
		contactButton.setBounds(566, 36, 125, 41);
		contentPane.add(contactButton);
		
		JButton aboutButton = new JButton("About");
		aboutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				AboutPage obj = new AboutPage();
				obj.setVisible(true);
			}
		});
		aboutButton.setBounds(716, 36, 130, 41);
		contentPane.add(aboutButton);
		
		JLabel home_slider_label = new JLabel("");

		Image image=new ImageIcon(this.getClass().getResource("/home_slider.gif")).getImage();
		home_slider_label.setIcon(new ImageIcon(image));
		home_slider_label.setBounds(55, 100, 855, 325);
		contentPane.add(home_slider_label);
		
		JLabel movie_label1 = new JLabel("New label");
		movie_label1.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label1.setBounds(12, 490, 114, 176);
		movie_label1.setIcon(getCustomImageIcon("movies (1).gif"));
		contentPane.add(movie_label1);
		
		JLabel movie_label2 = new JLabel("New label");
		movie_label2.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label2.setIcon(getCustomImageIcon("movies (2).gif"));
		movie_label2.setBounds(146, 490, 114, 176);
		contentPane.add(movie_label2);
		
		JLabel movie_label3 = new JLabel("New label");
		movie_label3.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label3.setBackground(new Color(153, 180, 209));
		movie_label3.setIcon(getCustomImageIcon("movies (3).gif"));
		movie_label3.setBounds(285, 490, 114, 176);
		contentPane.add(movie_label3);
		
		JLabel movie_label4 = new JLabel("New label");
		movie_label4.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label4.setIcon(getCustomImageIcon("movies (4).gif"));
		movie_label4.setBounds(422, 490, 114, 176);
		contentPane.add(movie_label4);
		

		
		JLabel movie_label5 = new JLabel("New label");
		movie_label5.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label5.setIcon( getCustomImageIcon("movies (5).gif"));
		movie_label5.setBounds(566, 490, 114, 176);
		contentPane.add(movie_label5);
		

		JLabel movie_label6 = new JLabel("New label");
		movie_label6.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label6.setIcon(getCustomImageIcon("movies (6).gif"));
		movie_label6.setBounds(703, 490, 114, 176);
		contentPane.add(movie_label6);
		
		JLabel movie_label7 = new JLabel("New label");
		movie_label7.setHorizontalAlignment(SwingConstants.CENTER);
		movie_label7.setIcon(getCustomImageIcon("movies (7).jpg"));
		movie_label7.setBounds(842, 490, 114, 176);
		contentPane.add(movie_label7);
		
		JButton movieOneButton = new JButton("Sow Time");
		movieOneButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("troll_movie_details.png"), "troll", "1000");
				obj.setVisible(true);
			}
		});
		movieOneButton.setBounds(12, 679, 114, 25);
		contentPane.add(movieOneButton);
		
		JButton movieTwoButton = new JButton("Sow Time");
		movieTwoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("shut in.png"), "shut in 2D", "500");
				obj.setVisible(true);
			}
		});
		movieTwoButton.setBounds(146, 679, 114, 25);
		contentPane.add(movieTwoButton);
		
		JButton movieThreeButton = new JButton("Sow Time");
		movieThreeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("THE_BFG.png"), "The BFG 3D", "1100");
				obj.setVisible(true);
			}
		});
		movieThreeButton.setBounds(285, 679, 114, 25);
		contentPane.add(movieThreeButton);
		
		JButton movieFourButton = new JButton("Sow Time");
		movieFourButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("aynabaji.png"), "Aynabaji 2D", "400");
				obj.setVisible(true);
			}
		});
		movieFourButton.setBounds(422, 679, 114, 25);
		contentPane.add(movieFourButton);
		
		JButton movieFiveButton = new JButton("Sow Time");
		movieFiveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("mona.png"), "MOANA 3D", "1200");
				obj.setVisible(true);
			}
		});
		movieFiveButton.setBounds(566, 679, 114, 25);
		contentPane.add(movieFiveButton);
		
		JButton movieSixButton = new JButton("Sow Time");
		movieSixButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("fantastic_beasts.png"), "Fantastic Beasts and Where to Find Them (3D)", "1000");				
				obj.setVisible(true);
			}
		});
		movieSixButton.setBounds(703, 679, 114, 25);
		contentPane.add(movieSixButton);
		
		JButton movieSevenButton = new JButton("Sow Time");
		movieSevenButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				ShowTimeAndDetails_Panel obj = new ShowTimeAndDetails_Panel(getCustomImageIcon("Doctor_Strange.png"), "Doctor Strange (3D)", "1200");
				obj.setVisible(true);
				
			}
		});
		movieSevenButton.setBounds(842, 679, 114, 25);
		contentPane.add(movieSevenButton);
	}
	

	// using for get image icon 
	public ImageIcon getCustomImageIcon(String filename){
		
		return new ImageIcon(new ImageIcon(this.getClass().getResource("/"+filename)).getImage());
	}
}
