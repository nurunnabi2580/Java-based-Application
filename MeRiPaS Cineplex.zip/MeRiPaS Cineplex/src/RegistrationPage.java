import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class RegistrationPage extends JFrame {

	private JPanel contentPane;
	private JTextField nameTF;
	private JTextField passwordTF;
	private JTextField phoneTF;
	private JTextField genderTF;
	private JTextField emailTF;
	
	
	Connection conn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrationPage frame = new RegistrationPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistrationPage() {
		setTitle("Registration");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Registration Panel");
		lblNewLabel.setForeground(new Color(255, 69, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 34));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(261, 37, 487, 73);
		contentPane.add(lblNewLabel);
		
		nameTF = new JTextField();
		nameTF.setFont(new Font("Tahoma", Font.BOLD, 20));
		nameTF.setBounds(350, 123, 340, 59);
		contentPane.add(nameTF);
		nameTF.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setBounds(149, 123, 189, 43);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Phone:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_2.setForeground(new Color(0, 0, 255));
		lblNewLabel_2.setBounds(128, 415, 199, 34);
		contentPane.add(lblNewLabel_2);
		
		passwordTF = new JTextField();
		passwordTF.setFont(new Font("Tahoma", Font.BOLD, 20));
		passwordTF.setBounds(348, 309, 340, 59);
		contentPane.add(passwordTF);
		passwordTF.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					conn = 	DB_Mysql_Connect.connectDB();
					System.out.print("Database is connected !");

		
					PreparedStatement updateemp = conn.prepareStatement("INSERT INTO user_info (name, email, password, phone , gender) VALUES (?,?,?,?,?)");
					updateemp.setString(1, nameTF.getText().toString());
					updateemp.setString(2, emailTF.getText().toString());

					updateemp.setString(3, passwordTF.getText().toString());

					updateemp.setString(4, phoneTF.getText().toString());

					updateemp.setString(5, genderTF.getText().toString());
					updateemp.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "Successfull");
					
					
				}catch (Exception dde) {
					System.out.print("Error:" + e);
				}
				finally{
					try {
						conn.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					setVisible(false);
					dispose();
					
					Home obj = new Home();
					obj.setVisible(true);
					
					
				}
				
				
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setForeground(new Color(34, 139, 34));
		btnNewButton.setBounds(565, 610, 125, 53);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("Password:");
		lblNewLabel_3.setForeground(new Color(0, 0, 255));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_3.setBounds(97, 322, 130, 30);
		contentPane.add(lblNewLabel_3);
		
		phoneTF = new JTextField();
		phoneTF.setFont(new Font("Tahoma", Font.BOLD, 20));
		phoneTF.setBounds(348, 404, 340, 59);
		contentPane.add(phoneTF);
		phoneTF.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Gender:");
		lblNewLabel_4.setForeground(new Color(0, 0, 255));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_4.setBounds(128, 505, 130, 43);
		contentPane.add(lblNewLabel_4);
		
		genderTF = new JTextField();
		genderTF.setFont(new Font("Tahoma", Font.BOLD, 20));
		genderTF.setBounds(348, 501, 340, 59);
		contentPane.add(genderTF);
		genderTF.setColumns(10);
		
		emailTF = new JTextField();
		emailTF.setFont(new Font("Tahoma", Font.BOLD, 20));
		emailTF.setColumns(10);
		emailTF.setBounds(350, 220, 340, 59);
		contentPane.add(emailTF);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setForeground(Color.BLUE);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblEmail.setBounds(151, 227, 201, 43);
		contentPane.add(lblEmail);
		
		JButton homeButton = new JButton("Home");
		homeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				dispose();
				
				Home obj = new Home();
				obj.setVisible(true);
			}
		});
		homeButton.setBounds(79, 13, 153, 43);
		contentPane.add(homeButton);
	}

}
