import java.sql.*;
import javax.swing.JOptionPane;

@SuppressWarnings("unused")
public class DB_Mysql_Connect {
	
	public static Connection connectDB()    
	{
	    Connection conn=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
	
			conn = DriverManager.getConnection("jdbc:mysql://localhost/cinplex","root", "");
			System.out.print("Database is connected !");
			return conn;
		}
		catch(Exception e)
		{
			System.out.print("Do not connect to DB - Error:"+e);
			return null;
		}     
	}
}
