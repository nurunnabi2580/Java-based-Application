import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;


public class AboutPage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AboutPage frame = new AboutPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AboutPage() {

		setTitle("About Page");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 780);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Home");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				Home obj = new Home();
				obj.setVisible(true);
			}
		});
		button.setBounds(98, 27, 141, 41);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Parchase");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				LoginPage obj = new LoginPage();
				obj.setVisible(true);
			}
		});
		button_1.setBounds(261, 27, 130, 41);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Member");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				MemberPage obj = new MemberPage();
				obj.setVisible(true);
			}
		});
		button_2.setBounds(414, 27, 125, 41);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Contact");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				ContactPage obj = new ContactPage();
				obj.setVisible(true);
			}
		});
		button_3.setBounds(558, 27, 125, 41);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("About");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				setVisible(false);
				dispose();
				
				AboutPage obj = new AboutPage();
				obj.setVisible(true);
			}
		});
		button_4.setBounds(708, 27, 130, 41);
		contentPane.add(button_4);
		
		JLabel about_label = new JLabel("");
		about_label.setHorizontalAlignment(SwingConstants.CENTER);
		about_label.setBounds(56, 110, 871, 586);
		about_label.setIcon(getCustomImageIcon("about.png"));
		contentPane.add(about_label);
	}
	public ImageIcon getCustomImageIcon(String filename){
		return new ImageIcon(new ImageIcon(this.getClass().getResource("/"+filename)).getImage());
	}

}
