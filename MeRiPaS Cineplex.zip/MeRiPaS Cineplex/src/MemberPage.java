import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;


public class MemberPage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MemberPage frame = new MemberPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MemberPage() {

		setTitle("Member Page");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 780);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton homeButton = new JButton("Home");
		homeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false); //you can't see me!
				dispose(); //Destroy the JFrame object
				
				Home obj = new Home();
				obj.setVisible(true);
			}
		});
		homeButton.setBounds(106, 35, 141, 41);
		contentPane.add(homeButton);
		
		JButton parchaseButton = new JButton("Parchase");
		parchaseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false); //you can't see me!
				dispose(); //Destroy the JFrame object
				
				LoginPage obj = new LoginPage();
				obj.setVisible(true);
			}
		});
		parchaseButton.setBounds(269, 35, 130, 41);
		contentPane.add(parchaseButton);
		
		JButton memberButton = new JButton("Member");
		memberButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				MemberPage obj = new MemberPage();
				obj.setVisible(true);
				
			}
		});
		memberButton.setBounds(422, 35, 125, 41);
		contentPane.add(memberButton);
		
		JButton contactButton = new JButton("Contact");
		contactButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false); //you can't see me!
				dispose(); //Destroy the JFrame object
				
				ContactPage obj = new ContactPage();
				obj.setVisible(true);
			}
		});
		contactButton.setBounds(566, 35, 125, 41);
		contentPane.add(contactButton);
		
		JButton aobutButton = new JButton("About");
		aobutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false); //you can't see me!
				dispose(); //Destroy the JFrame object
				
				AboutPage obj = new AboutPage();
				obj.setVisible(true);
			}
		});
		aobutButton.setBounds(716, 35, 130, 41);
		contentPane.add(aobutButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(158, 149, 738, 555);
		lblNewLabel.setIcon(getCustomImageIcon("member.png"));
		contentPane.add(lblNewLabel);
	}
	public ImageIcon getCustomImageIcon(String filename){
		return new ImageIcon(new ImageIcon(this.getClass().getResource("/"+filename)).getImage());
	}

}
