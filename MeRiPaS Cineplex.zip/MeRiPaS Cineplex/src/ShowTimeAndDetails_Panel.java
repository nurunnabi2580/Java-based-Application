import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;


public class ShowTimeAndDetails_Panel extends JFrame {

	private JPanel contentPane;
	private JLabel currentMovie_label;
	ImageIcon icon;
	private JButton btnBuyTicket;
	public static String movieName;
	public static String ticketPrice;
	private JLabel movie_price_label;

	
	


	

	/**
	 * Create the frame.
	 */
	public ShowTimeAndDetails_Panel(ImageIcon icon, String movieName, String price) {
		setTitle("Show Time");
		this.movieName = movieName;
		ticketPrice = price;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 900);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Home");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				Home obj = new Home();
				obj.setVisible(true);
			}
		});
		button.setBounds(110, 33, 141, 41);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Parchase");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				LoginPage obj = new LoginPage();
				obj.setVisible(true);
			}
		});
		button_1.setBounds(273, 33, 130, 41);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Member");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				dispose();
				
				MemberPage obj = new MemberPage();
				obj.setVisible(true);
			}
		});
		button_2.setBounds(426, 33, 125, 41);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Contact");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
				dispose();
				
				ContactPage obj = new ContactPage();
				obj.setVisible(true);
			}
		});
		button_3.setBounds(570, 33, 125, 41);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("About");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				AboutPage obj = new AboutPage();
				obj.setVisible(true);
			}
		});
		button_4.setBounds(720, 33, 130, 41);
		contentPane.add(button_4);
		
		currentMovie_label = new JLabel("");
		currentMovie_label.setHorizontalAlignment(SwingConstants.CENTER);
		currentMovie_label.setIcon(icon);
		currentMovie_label.setBounds(12, 166, 943, 674);
		contentPane.add(currentMovie_label);
		
		btnBuyTicket = new JButton("Buy Ticket");
		btnBuyTicket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				LoginPage obj = new LoginPage();
				obj.setVisible(true);
			}
		});
		btnBuyTicket.setFont(new Font("Tahoma", Font.BOLD, 19));
		btnBuyTicket.setBackground(new Color(0, 102, 204)); 
		btnBuyTicket.setForeground(Color.GREEN);
		btnBuyTicket.setBounds(777, 112, 141, 41);
		contentPane.add(btnBuyTicket);
		
		movie_price_label = new JLabel("zzz");
		movie_price_label.setHorizontalAlignment(SwingConstants.CENTER);
		movie_price_label.setBounds(572, 112, 182, 41);
		contentPane.add(movie_price_label);
		movie_price_label.setText("Ticket Price: "+price);
	}
}
