import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import java.awt.Color;

import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class BuyTicket extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	private Connection conn;
	private String phone;
	private JComboBox price_CB;
	
	public BuyTicket(String phone) {
		this.phone = phone;
		
		System.out.println("\nBuyTicket:   "+ phone);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox movie_name_CB = new JComboBox();
		movie_name_CB.setModel(new DefaultComboBoxModel(new String[] {ShowTimeAndDetails_Panel.movieName, "Select Movies Name", "Troll", "shut in 2D", "The BFG 3D", "Aynabaji 2D", "MOANA 3D", "Fantastic Beasts and Where to Find Them (3D)", "Doctor Strange (3D)"}));
		movie_name_CB.setBounds(367, 240, 272, 49);
		contentPane.add(movie_name_CB);
	
		
		JComboBox time_CB = new JComboBox();
		time_CB.setModel(new DefaultComboBoxModel(new String[] {"11.10 AM", "4.10 PM", "7.00 PM", "10.00 PM"}));
		time_CB.setBounds(367, 321, 272, 41);
		contentPane.add(time_CB);
		
		JButton btnNewButton = new JButton("Buy Ticket");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//System.out.println(phone + "dddddddddddddddddddddddddd");
				
				try {
					conn = 	DB_Mysql_Connect.connectDB();
					System.out.print("Database is connected !");
					
					String movie_name = movie_name_CB.getSelectedItem().toString();
					String price = price_CB.getSelectedItem().toString();
					String time = time_CB.getSelectedItem().toString();

		
					 String query = "UPDATE user_info SET show_time='"+time+"', price = '"+price+"', movie_name = '"+ movie_name +"' WHERE phone = '"+phone+"';";
					 System.out.println("\n"+query);
					 
					 PreparedStatement updateemp = conn.prepareStatement(query);
					 
					 updateemp.executeUpdate();
						
					
					JOptionPane.showMessageDialog(null, "Successfull Buying");
					
					
				}catch (Exception dde) {
					System.out.print("Error:" + e);
				}
				finally{
					try {
						conn.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					setVisible(false);
					dispose();
					
					FinalView obj = new FinalView(phone);
					obj.setVisible(true);
					
					
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(367, 499, 272, 49);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Take Your Ticket");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(215, 67, 528, 73);
		contentPane.add(lblNewLabel);
		
		price_CB = new JComboBox();
		price_CB.setModel(new DefaultComboBoxModel(new String[] {ShowTimeAndDetails_Panel.ticketPrice, "1000", "500", "1200", "400", "800"}));
		price_CB.setBounds(370, 403, 269, 41);
		contentPane.add(price_CB);
	}

}
