import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class LoginPage extends JFrame {

	private JPanel contentPane;
	private JTextField usernameTF;
	private JTextField passwordTF;
	private JButton btnNewButton;
	private JButton registrationButton;
	Connection conn;
	private JButton btnNewButton_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage frame = new LoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(getCustomImageIcon("login_logo.png"));
		lblNewLabel.setBounds(382, 144, 383, 268);
		contentPane.add(lblNewLabel);
		
		usernameTF = new JTextField();
		usernameTF.setBackground(new Color(51, 153, 255));
		usernameTF.setFont(new Font("Tahoma", Font.BOLD, 17));
		usernameTF.setBounds(355, 453, 410, 52);
		contentPane.add(usernameTF);
		usernameTF.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Phone No:");
		lblNewLabel_1.setForeground(new Color(0, 0, 153));
		
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(204, 453, 139, 52);
		contentPane.add(lblNewLabel_1);
		
		passwordTF = new JTextField();
		passwordTF.setBackground(new Color(0, 153, 255));
		passwordTF.setFont(new Font("Tahoma", Font.BOLD, 17));
		passwordTF.setColumns(10);
		passwordTF.setBounds(355, 518, 410, 52);
		contentPane.add(passwordTF);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setForeground(new Color(0, 0, 153));
		lblPassword.setHorizontalAlignment(SwingConstants.LEFT);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPassword.setBounds(204, 518, 139, 52);
		contentPane.add(lblPassword);
		
		btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				conn = 	DB_Mysql_Connect.connectDB();
				System.out.print("Database is connected !");
				
				try{
					String query = "select * from user_info WHERE phone='"+usernameTF.getText().toString()+"' AND password ='"+passwordTF.getText().toString()+"'";
					
					//System.out.println(query);
					
					Statement stt = conn.createStatement();

					ResultSet rs = stt.executeQuery(query);
					//System.out.println("Id   First Name    Last Name");
					while (rs.next()) {
						String phone = rs.getString("phone");
						String password = rs.getString("password");

						if(usernameTF.getText().toString().compareTo(phone) == 0 && 
								passwordTF.getText().toString().compareTo(password) ==0){
							setVisible(false);
							dispose();
							
	
							BuyTicket obj = new BuyTicket(phone);
							
							System.out.println("Phone:  "+ phone);
							obj.setVisible(true);
						}
					}
					conn.close();
					
				}catch(Exception ee){
					System.err.println(ee);
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(355, 597, 410, 52);
		contentPane.add(btnNewButton);
		
		registrationButton = new JButton("Registration");
		registrationButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				RegistrationPage obj = new RegistrationPage();
				obj.setVisible(true);
				
			}
		});
		registrationButton.setBounds(626, 669, 139, 25);
		contentPane.add(registrationButton);
		
		btnNewButton_1 = new JButton("Home");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
				
				Home obj = new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(819, 47, 127, 52);
		contentPane.add(btnNewButton_1);
	}
	public ImageIcon getCustomImageIcon(String filename){
		return new ImageIcon(new ImageIcon(this.getClass().getResource("/"+filename)).getImage());
	}
}
